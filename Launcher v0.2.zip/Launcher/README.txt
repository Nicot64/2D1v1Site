Aloha und danke fürs Herunterladen des 2D 1v1 Launchers!
Wenn du den Launcher für das erste Mal startest (oder wenn die Dateien gelöscht werden) erstellt sich
ein "Files"-Ordner im gleichen Verzeichnis des Launchers.
Dort werden alle Daten des Spieles gespeichert, also ändere am besten nichts an diesem Ordner oder verschiebe
ihn nicht.
Viel Spaß!